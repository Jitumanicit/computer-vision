
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>    
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
       
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
	
	
	.img-valign {
       vertical-align: middle;	  
       margin-bottom: 0.75em;
    }

    .text1 {
       font-size: 44px;
    }

    .text2 {
       font-size: 14px;	   
    }
	
	p{
	  /*border-bottom: 1px solid;*/
	  margin-bottom: 0.75em;
	}
		
	hr
     {
        color: #f00;
        background-color: #f00;
        height: 5px;
     }

    .media hr{
        color: #f00;
        background-color: #f00;
        height: 0.5px;
     }

    h4{
       color:#f00;    	
    }
    h3,h2
    {
     color: #f00;    
    }


  </style>
</head>
<body>

<div class="bs-example">
    <nav id="myNavbar" class="navbar-fixed-top navbar-inverse" role="navigation">
       
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="Home">News</a>
            </div>           
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="Home">Home</a></li>
                    <li><a href="About">About Us</a></li>                    
					<li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Category<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url().'admin/Entertainment' ?>">Entertainment</a></li>
                            <li><a href="Business">Business</a></li>
                            <li><a href="Politics">Politics</a></li>                            
							<li><a href="Technology">Science and Technology</a></li>
                            <li><a href="Sports">Sports</a></li>
							<li><a href="Law">Law</a></li>
                            <li><a href="Education">Education</a></li>							
							<li><a href="Lifestyle">Lifestyle</a></li>
							<li><a href="LawOrder">Law and Order</a></li>
							<li><a href="Others">Others</a></li>
                        </ul>
                    </li>					
				    <li><a href="Video">Video</a></li>
					<li><a href="RecentNews">Recent News</a></li>
                </ul>              
            </div>
        </div>
    </nav>
</div>


<div class="jumbotron">
  <div class="container text-center">
    <h1>News</h1> 
  </div>
</div>

<div class="container-fluid bg-3"> 
  <div class="row">
    <div class="col-md-12"> 
      <div class="col-sm-3"></div> 
	  <div class="col-sm-6">       
         <video width="100%" height="340" controls>
          <source src="<?php echo base_url().'uploads/images/'.$results[0]['picture']; ?>" type="video/mp4">
         </video> 	  
	  </div>     
      <div class="col-sm-3"></div> 
     </div> 
   </div>
  <br>
 <hr>
</div>
 
<div class="container-fluid bg-3 text-center">    
  <h2>Video</h2>
  <div class="row">
    <?php foreach($results as $val)
	{			
	?>
      <div class="col-sm-3">     
        <video width="320" height="240" controls>
          <source src="<?php echo base_url().'uploads/images/'.$val['picture']; ?>" type="video/mp4">
        </video> 
         <p><?php echo $val['Title'];   ?></p>
       </div>
	<?php } ?> 	
  </div>
</div><br>

<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>




</body>
</html>
