        </div>
        <!-- /page content -->		
		
        <!-- footer content -->
        <footer>
            <div class="pull-center">
              <a href="https://www.mobisofttech.co.in"> Mobisoft Technology India Pvt. Ltd.</a>Colorlib 2011-2018 All right reserved.
            </div>
            <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
	
   
    <!-- Bootstrap -->
    <script src="<?php echo base_url('assets/AdminPanel/js/bootstrap.min.js')?>"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url('assets/AdminPanel/js/fastclick.js')?>"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url('assets/AdminPanel/js/nprogress.js')?>"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url('assets/AdminPanel/js/bootstrap-progressbar.min.js')?>"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url('assets/AdminPanel/js/icheck.min.js')?>"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url('assets/AdminPanel/js/moment.min.js')?>"></script>	
    <script src="<?php echo base_url('assets/AdminPanel/js/daterangepicker.js')?>"></script>
	<script src="<?php echo base_url('assets/AdminPanel/js/bootstrap-datetimepicker.min.js')?>"></script>	
    <!-- bootstrap-wysiwyg -->
    <script src="<?php echo base_url('assets/AdminPanel/js/bootstrap-wysiwyg.min.js')?>"></script>
    <script src="<?php echo base_url('assets/AdminPanel/js/jquery.hotkeys.js')?>"></script>
    <script src="<?php echo base_url('assets/AdminPanel/js/prettify.js')?>"></script>
    <!-- jQuery Tags Input -->
    <script src="<?php echo base_url('assets/AdminPanel/js/jquery.tagsinput.js')?>"></script>
    <!-- Switchery -->
    <script src="<?php echo base_url('assets/AdminPanel/js/switchery.min.js')?>"></script>
    <!-- Select2 -->
    <script src="<?php echo base_url('assets/AdminPanel/js/select2.full.min.js')?>"></script>
    <!-- Parsley -->
    <script src="<?php echo base_url('assets/AdminPanel/js/parsley.min.js')?>"></script>
    <!-- Autosize -->
    <script src="<?php echo base_url('assets/AdminPanel/js/autosize.min.js')?>"></script>
    <!-- jQuery autocomplete -->
    <script src="<?php echo base_url('assets/AdminPanel/js/jquery.autocomplete.min.js')?>"></script>
    <!-- starrr -->
    <script src="<?php echo base_url('assets/AdminPanel/js/starrr.js')?>"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/AdminPanel/js/custom.min.js')?>"></script>	