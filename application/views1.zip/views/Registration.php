<?php //include('header.php'); ?>
	<!-- page content -->
      <div class="right_col" role="main">
       <div class="">
        <div class="page-title">
          <div class="title_left">
            <!--<h3>Form Elements</h3>-->
          </div>              
        </div>
        <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Registration</h2>
                    <ul class="nav navbar-right panel_toolbox">
                       <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                       <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>                       
                       </li>
                       <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
				  
                  <div class="x_content">
                   <br/>									
                    <form id="postdata" method="post" class="form-horizontal form-label-left" action="<?php echo base_url().'admin/NewRegistration';?>" enctype="multipart/form-data">
                      <div> 
				        <?php if($msg!='')
				         {
				           echo '<script>$(document).ready(function(){  success(); });</script>'	
                         ?>
                        <div class="alert alert-success" id="successmsg" role="alert"> <?php echo $msg; ?></div>
				        <?php
				         }
				        ?>
			          </div>
					  
					  <div class="form-group">					   
                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Username<span class="required"></span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                          <input type="text" id="Username" name="Username" class="form-control col-md-7 col-xs-12" required>
						  <input type="hidden" id="types" name="types" value="sub_admin" class="form-control col-md-7 col-xs-12" >						  
                        </div>							 
						<label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Password<span class="required"></span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                          <input type="password" id="Password" name="Password" class="form-control col-md-7 col-xs-12" required>
                        </div>							 
                      </div>
					  
					  <div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Email<span class="required">*</span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                           <input type="text" id="Email" name="Email" class="form-control col-md-7 col-xs-12" required> 
                        </div>						 
						<label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Phone<span class="required">*</span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                          <input type="text" id="Phone" name="Phone" class="form-control col-md-7 col-xs-12" required> 
                        </div>						
                      </div>
					  
                      <div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">File<span class="required">*</span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                           <input type="file" id="picture" name="picture" required> 
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                           <input type="hidden" id="reporter_id" name="reporter_id" class="form-control col-md-7 col-xs-12"> 
						   <input type="hidden" id="pan_card" name="pan_card" class="form-control col-md-7 col-xs-12"> 
                           <input type="hidden" id="address_proof" name="address_proof" class="form-control col-md-7 col-xs-12"> 
						   <input type="hidden" id="organization" name="organization" class="form-control col-md-7 col-xs-12"> 
                        </div>	
                      </div>					  
			       <!--<div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Id<span class="required">*</span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12"></div>
						<label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Address Proof<span class="required">*</span></label>
                        <div class="col-md-4 col-sm-4 col-xs-12"></div>	
                      </div>					  
					   <div class="form-group">                        					 
						 <label class="control-label col-md-2 col-sm-2 col-xs-12" for="last-name">Organization<span class="required">*</span></label>
                         <div class="col-md-4 col-sm-4 col-xs-12"></div>						
                      </div>-->	
                      <div class="form-group" align="center">
                         <input type="submit" name="Submit" value="Submit" class="btn btn-primary">		 
                      </div>					 
                   </form>		 
                 </div>
                </div>
              </div>
            </div>  
          </div>
        </div>
      </div>
      <!-- /page content -->
      <script>
	    function success()
   	    {			
	      $('#successmsg').delay(2000).fadeOut('slow');	
		  var delay = 2000; 
          setTimeout(function(){window.location.href = "http://localhost/News/admin/Registration";}, delay);		   
        } 
	  </script>
	 		
	 <?php include('footer.php');?>	
	 