
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">                 
              </div>              
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add Sub Category</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>                       
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>				  
                  <div class="x_content">
                    <br/>									
                     <form id="postdata" method="post" class="form-horizontal form-label-left" action="<?php echo base_url().'admin/saveSubCategory';?>" enctype="multipart/form-data">
                       <div class="form-group">					   
                        <label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Category <span class="required">*</span></label>
                         <div class="col-md-4 col-sm-4 col-xs-12">                           
						   <select name="category" id="category" class="form-control col-md-7 col-xs-12" required>
						       <option value="">select</option>
							   <?php foreach($result as $val) { ?>
							       <option value="<?php echo $val['id']; ?>"><?php echo $val['category']; ?></option>
							   <?php } ?>							   
						   </select>
                         </div>						 
						<label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">Sub Category <span class="required">*</span></label>
                          <div class="col-md-4 col-sm-4 col-xs-12">
                           <input type="text" id="subcategory" name="subcategory" class="form-control col-md-7 col-xs-12" required>
                          </div>				 
                       </div> 	   
                       <div class="form-group" align="center">
                           <input type="submit" name="userSubmit" value="Submit" class="btn btn-primary">		 
                       </div>					   
                     </form>		 
                   </div>
                 </div>
               </div>
             </div>  
            </div>
          </div>
        </div>     
    <?php include('footer.php');?>
 
	
